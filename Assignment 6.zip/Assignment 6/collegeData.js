const fs = require("fs");
const Sequelize = require('sequelize');
const sequelize = new Sequelize('assignment6', 'niranj', 'Niranj@12$A', {
    host: 'supabase',
    dialect: 'postgres',
    dialectOptions: { ssl: { rejectUnauthorized: false } },
    query: { raw: true }
});
const Student = sequelize.define('Student', {
    studentNum: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
    firstName: Sequelize.STRING,
    lastName: Sequelize.STRING,
    email: Sequelize.STRING,
    addressStreet: Sequelize.STRING,
    addressCity: Sequelize.STRING,
    addressProvince: Sequelize.STRING,
    TA: Sequelize.BOOLEAN,
    status: Sequelize.STRING,
    course: Sequelize.INTEGER
});

const Course = sequelize.define('Course', {
    courseId: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
    courseCode: Sequelize.STRING,
    courseDescription: Sequelize.STRING
});

Course.hasMany(Student, { foreignKey: 'course' });


class Data{
    constructor(students, courses){
        this.students = students;
        this.courses = courses;
    }
}

let dataCollection = null;

module.exports.initialize = () => {
    return new Promise((resolve, reject) => {
        sequelize.sync()
            .then(() => resolve())
            .catch(() => reject("unable to sync the database"));
    });
};

module.exports.getAllStudents = () => {
    return new Promise((resolve, reject) => {
        Student.findAll()
            .then(data => resolve(data))
            .catch(() => reject("no results returned"));
    });
};

module.exports.getStudentsByCourse = (course) => {
    return new Promise((resolve, reject) => {
        Student.findAll({ where: { course: course } })
            .then(data => resolve(data))
            .catch(() => reject("no results returned"));
    });
};

module.exports.getStudentByNum = (num) => {
    return new Promise((resolve, reject) => {
        Student.findAll({ where: { studentNum: num } })
            .then(data => resolve(data[0]))
            .catch(() => reject("no results returned"));
    });
};

module.exports.getCourses = () => {
    return new Promise((resolve, reject) => {
        Course.findAll()
            .then(data => resolve(data))
            .catch(() => reject("no results returned"));
    });
};

module.exports.getCourseById = (id) => {
    return new Promise((resolve, reject) => {
        Course.findAll({ where: { courseId: id } })
            .then(data => resolve(data[0]))
            .catch(() => reject("no results returned"));
    });
};

module.exports.updateStudent = function (studentData) {
    studentData.TA = (studentData.TA) ? true : false;
    for (var prop in studentData) {
        if (studentData[prop] == "") studentData[prop] = null;
    }
    return new Promise(function (resolve, reject) {
        Student.update(studentData, {
            where: { studentNum: studentData.studentNum }
        }).then(() => {
            resolve();
        }).catch(() => {
            reject("unable to update student");
        });
    });
};


module.exports.updateStudent = (studentData) => {
    studentData.TA = studentData.TA ? true : false;
    for (let key in studentData) {
        if (studentData[key] === "") {
            studentData[key] = null;
        }
    }
    return new Promise((resolve, reject) => {
        Student.update(studentData, { where: { studentNum: studentData.studentNum } })
            .then(() => resolve())
            .catch(() => reject("unable to update student"));
    });
};
module.exports.addCourse = (courseData) => {
    for (let key in courseData) {
        if (courseData[key] === "") {
            courseData[key] = null;
        }
    }
    return new Promise((resolve, reject) => {
        Course.create(courseData)
            .then(() => resolve())
            .catch(() => reject("unable to create course"));
    });
};

module.exports.updateCourse = (courseData) => {
    for (let key in courseData) {
        if (courseData[key] === "") {
            courseData[key] = null;
        }
    }
    return new Promise((resolve, reject) => {
        Course.update(courseData, { where: { courseId: courseData.courseId } })
            .then(() => resolve())
            .catch(() => reject("unable to update course"));
    });
};

